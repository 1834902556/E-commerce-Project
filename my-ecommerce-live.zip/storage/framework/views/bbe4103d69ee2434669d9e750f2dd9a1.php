<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/dist/css/style.min.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/dist/css/pages/dashboard1.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>admin/assets/node_modules/dropify/dist/css/dropify.min.css">
<link rel="stylesheet" type="text/css"
href="<?php echo e(asset('/')); ?>admin/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css"
href="<?php echo e(asset('/')); ?>admin/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>admin/assets/node_modules/summernote/dist/summernote-bs4.css">
<?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/admin/include/link.blade.php ENDPATH**/ ?>