<footer class="footer">
    © 2021 Design & Developed by Najmul Islam
    <a href="https://www.wrappixel.com/">WrapPixel</a>
</footer>
<?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>