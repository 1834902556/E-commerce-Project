<?php $__env->startSection('title'); ?>
    ADD BLOG PAGE
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 bg-primary mx-auto p-5">
                    <h3 class="text-center text-white"><?php echo e(Session::get('msg')); ?></h3>
                    <h1 class="text-center text-white">Add Blog</h1>
                    <form action="<?php echo e(route('insert.blog')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="title" id="name" class="form-control mt-5"
                            placeholder="Enter Title">
                        <textarea name="description" id="description" cols="30" rows="5" placeholder="Enter Description"
                            class="form-control mt-3"></textarea><br><br>
                        <input type="file" name="img" id="img" class="form-control"><br><br>
                        <input type="submit" name="btn" id="btn" class="btn bg-success">
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batch-21\day-47\my-project\resources\views/addBlog.blade.php ENDPATH**/ ?>