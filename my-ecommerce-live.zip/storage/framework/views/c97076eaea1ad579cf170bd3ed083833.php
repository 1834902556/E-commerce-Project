<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Data Table</h4>
            <h6 class="card-subtitle">Data table example</h6>
            <div class="table-responsive m-t-40">
                <p class="text-center text-success"><?php echo e(session('msg')); ?> </p>
                <table class="table table-striped border">
                    <tr>
                        <th>Product Id</th>.
                        <td><?php echo e($product->id); ?></td>
                    </tr>
                    <tr>
                        <th>Product Name</th>.
                        <td><?php echo e($product->name); ?></td>
                    </tr>
                    <tr>
                        <th>Product Code</th>.
                        <td><?php echo e($product->code); ?></td>
                    </tr>
                    <tr>
                        <th>Product Model</th>.
                        <td><?php echo e($product->model); ?></td>
                    </tr>
                    <tr>
                        <th>Product Category</th>.
                        <td><?php echo e($product->category->Category_Name); ?></td>
                    </tr>
                    <tr>
                        <th>Product Sub Category</th>.
                        <td><?php echo e($product->subCategory); ?></td>
                    </tr>
                    <tr>
                        <th>Product Brand</th>.
                        <td><?php echo e($product->brand->name); ?></td>
                    </tr>
                    <tr>
                        <th>Product Unit</th>.
                        <td><?php echo e($product->unit->name); ?></td>
                    </tr>
                    <tr>
                        <th>Product Stock Amount</th>.
                        <td><?php echo e($product->stock_amount); ?></td>
                    </tr>
                    <tr>
                        <th>Product Regular Price</th>.
                        <td><?php echo e($product->regular_price); ?></td>
                    </tr>
                    <tr>
                        <th>Product Selling Price</th>.
                        <td><?php echo e($product->selling_price); ?></td>
                    </tr>
                    <tr>
                        <th>Short Description</th>.
                        <td><?php echo e($product->sort_description); ?></td>
                    </tr>
                    <tr>
                        <th>Long Description</th>.
                        <td><?php echo e($product->long_description); ?></td>
                    </tr>
                    <tr>
                        <th>Product Feature Image</th>.
                        <td><img src="<?php echo e(asset($product->image)); ?>" alt="" height="100px" width="120px"></td>
                    </tr>  <tr>
                        <th>Product Other Image</th>.
                        <td>
                            <?php $__currentLoopData = $product->otherImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset($otherImage->image)); ?>" alt="" height="100px" width="120px">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Product Hit Count</th>.
                        <td><?php echo e($product->hit_count); ?></td>
                    </tr>
                    <tr>
                        <th>Product Sales Count</th>.
                        <td><?php echo e($product->sales_count); ?></td>
                    </tr>
                    <tr>
                        <th>Product Feature Status</th>.
                        <td><?php echo e($product->feature_status); ?></td>
                    </tr>
                    <tr>
                        <th>Product Publication Status</th>.
                        <td><?php echo e($product->status== 1 ? 'published' : 'unpublished'); ?></td>
                    </tr>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/admin/product/detail.blade.php ENDPATH**/ ?>