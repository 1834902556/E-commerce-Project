<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Data Table</h4>
            <h6 class="card-subtitle">Data table example</h6>
            <div class="table-responsive m-t-40">
                <p class="text-center text-success"><?php echo e(session('msg')); ?> </p> 
                <table id="myTable" class="table table-striped border">
                    <thead>
                        <tr>
                            <th>SL NO.</th>
                            <th>Category Name</th>
                            <th>Category Description</th>
                            <th>Category Image</th>
                            <th>Punlication Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($category->Category_Name); ?></td>
                            <td><?php echo e($category->Category_Description); ?></td>
                            <td><img src="<?php echo e(asset($category->Category_Image)); ?>" alt="<?php echo e($category->Category_Image); ?>" height="50px" width="80px"></td>
                            <td><?php echo e($category->Status== 1 ? 'published' : 'unpublished'); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit.category',['id'=>$category->id])); ?>" class="btn btn-success btn-sm" onclick="return confirm('Are you sure to edit it.')">
                                    <i class="ti-agenda"></i>
                                </a>
                                <a href="<?php echo e(route('delete.category',['id'=>$category->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete it.')">
                                    <i class="ti-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/admin/category/manage_category.blade.php ENDPATH**/ ?>