<?php $__env->startSection('title'); ?>
Add to cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 col-md-6 col-12">
          <div class="breadcrumbs-content">
            <h1 class="page-title">Cart</h1>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <ul class="breadcrumb-nav">
            <li><a href="index.html"><i class="lni lni-home"></i> Home</a></li>
            <li><a href="index.html">Shop</a></li>
            <li>Cart</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <p class="text-center text-success pt-2"> <?php echo e(session('msg')); ?></p>
  <div class="shopping-cart section">
    <div class="container">
      <div class="cart-list-head">
        <div class="cart-list-title">
          <div class="row">
            <div class="col-lg-4 col-md-3 col-12">
              <p>Product Name</p>
            </div>
            <div class="col-lg-2 col-md-2 col-12">
              <p>Quantity</p>
            </div>
            <div class="col-lg-2 col-md-2 col-12">
              <p>Unit Price</p>
            </div>
            <div class="col-lg-2 col-md-2 col-12">
              <p>Total</p>
            </div>
            <div class="col-lg-1 col-md-2 col-12">
              <p>Remove</p>
            </div>
          </div>
        </div>
        <?php ($sum=0); ?>
        <?php $__currentLoopData = $cart_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cart-single-list">
            <div class="row align-items-center">
              <div class="col-lg-1 col-md-1 col-12">
                <a href="product-details.html"><img
                    src="<?php echo e(asset($cart_product->image)); ?>" alt="#"></a>
              </div>
              <div class="col-lg-3 col-md-3 col-12">
                <h5 class="product-name"><a href=""><?php echo e($cart_product->name); ?></a></h5>
                <p class="product-des">
                  
                  
                </p>
              </div>
              <div class="col-lg-2 col-md-2 col-12">
                <form action="<?php echo e(route('update.cart_product',['id' => $cart_product->__raw_id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                  <div class="input-group">
                    <input class="form-control" value="<?php echo e($cart_product->qty); ?>" name="qty" min="1" required>
                    <input type="submit" class="btn btn-success" value="Update">
                  </div>
                </form>
              </div>
              <div class="col-lg-2 col-md-2 col-12">
                <p><?php echo e($cart_product->price); ?></p>
              </div>
              <div class="col-lg-2 col-md-2 col-12">
                <p><?php echo e($cart_product->price * $cart_product->qty); ?></p>
              </div>
              <div class="col-lg-1 col-md-2 col-12">
                <a class="remove-item" onclick=" return confirm('Are you sure to remove')" href="<?php echo e(route('remove.cart_product',['id'=>$cart_product->__raw_id])); ?>"><i class="lni
                    lni-close"></i></a>
              </div>
            </div>
          </div>
          <?php ($sum = $sum+($cart_product->price * $cart_product->qty)); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="total-amount">
            <div class="row">
              <div class="col-lg-8 col-md-6 col-12">
                <div class="left">
                  <div class="coupon">
                    <form action="#" target="_blank">
                      <input name="Coupon" placeholder="Enter Your Coupon">
                      <div class="button">
                        <button class="btn">Apply Coupon</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 col-12">
                <div class="right">
                  <ul>
                    <li>Cart Subtotal<span><?php echo e($sum); ?></span></li>
                    <li>Tax(15%)<span><?php echo e($tax = ($sum*15)/100); ?></span></li>
                    <li>Shipping<span><?php echo e($shipping=500); ?></span></li>
                    <li>Total Payable<span><?php echo e($sum+$tax+$shipping); ?></span></li>
                  </ul>
                  <div class="button">
                    <a href="<?php echo e(route('check.out.php')); ?>" class="btn">Checkout</a>
                    <a href="product-grids.html" class="btn btn-alt">Continue
                      shopping</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/website/cart/index.blade.php ENDPATH**/ ?>