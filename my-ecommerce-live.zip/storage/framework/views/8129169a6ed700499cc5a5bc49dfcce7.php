<?php $__env->startSection('title'); ?>
    MANAGE BLOG PAGE
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <h1 class="text-center">Manage Blogs</h1>
                    <table class="table-bordered table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>title</th>
                                <th>description</th>
                                <th>image</th>
                                <th>Edit/Delete</th>
                            </tr>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-top"><?php echo e($value['id']); ?></td>
                                    <td class="text-center align-top"><?php echo e($value['title']); ?></td>
                                    <td class="text-center align-top"><?php echo e($value['description']); ?></td>
                                    <td><img src="<?php echo e($value['image']); ?>" alt="" height="200px" width="200px"></td>
                                    <td class="align-top d-grid"><button type="button"
                                            class="btn bg-primary">Edit</button>&nbsp;
                                        &nbsp;<button class="btn bg-danger">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>

                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batch-21\day-47\my-project\resources\views/manageBlog.blade.php ENDPATH**/ ?>