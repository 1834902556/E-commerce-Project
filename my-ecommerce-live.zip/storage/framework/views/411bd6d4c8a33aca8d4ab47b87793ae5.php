<?php $__env->startSection('title'); ?>
    Blog Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2><?php echo e($blogs->title); ?></h2>
                    <img src="<?php echo e(asset("/$blogs->image")); ?>" alt="" height="100px" width="100px">
                    <p><?php echo e($blogs->description); ?></p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batch-21\day-47.a\my-project\resources\views/blogDetails.blade.php ENDPATH**/ ?>