<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/')); ?>assets/images/favicon.svg" />

    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/LineIcons.3.0.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/main.css" /><?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/website/link.blade.php ENDPATH**/ ?>