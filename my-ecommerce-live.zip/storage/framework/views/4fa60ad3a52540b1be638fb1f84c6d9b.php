<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Order Basic Information</h4>
            <div class="table-responsive m-t-40">
                <table class="table table-striped border">
                        <tr>
                            <th>Order ID</th>
                            <td><?php echo e($order->id); ?></td>
                        </tr>
                        <tr>
                            <th>Order Date</th>
                            <td><?php echo e($order->date); ?></td>
                        </tr>
                        <tr>
                            <th>Order Total</th>
                            <td><?php echo e($order->order_total); ?></td>
                        </tr>
                        <tr>
                            <th>Tax Total</th>
                            <td><?php echo e($order->tax_total); ?></td>
                        </tr>
                        <tr>
                            <th>Shipping Total</th>
                            <td><?php echo e($order->Shipping_total); ?></td>
                        </tr>
                        <tr>
                            <th>Order Status</th>
                            <td><?php echo e($order->order_status); ?></td>
                        </tr>
                        <tr>
                            <th>Delivery Address</th>
                            <td><?php echo e($order->delivary_address); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Type</th>
                            <td><?php echo e($order->payment_type); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Status</th>
                            <td><?php echo e($order->payment_status); ?></td>
                        </tr>
                        <tr>
                            <th>Currency</th>
                            <td><?php echo e($order->currency); ?></td>
                        </tr>
                        <tr>
                            <th>Transaction ID</th>
                            <td><?php echo e($order->transaction_id); ?></td>
                        </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Order Customer Information</h4>
            <div class="table-responsive m-t-40">
                <table class="table table-striped border">
                   <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Mobile Number</th>
                        <th>Email Address</th>
                        <th>Address</th>
                    </tr>
                   </thead>
                   <tbody>
                    <tr>
                        <td><?php echo e($order->customer->name); ?></td>
                        <td><?php echo e($order->customer->mobile); ?></td>
                        <td><?php echo e($order->customer->email); ?></td>
                        <td><?php echo e($order->customer->address); ?></td>
                    </tr>
                   </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Order Product Information</h4>
            <div class="table-responsive m-t-40">
                <table class="table table-striped border">
                   <thead>
                    <tr>
                        <th>SL No.</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Order Amount</th>
                        <th>Total Price</th>
                    </tr>
                   </thead>
                   <tbody>
                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($orderDetail->product_name); ?></td>
                        <td><?php echo e($orderDetail->product_price); ?></td>
                        <td><?php echo e($orderDetail->product_qty); ?></td>
                        <td><?php echo e($orderDetail->product_price * $orderDetail->product_qty); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xmapp\htdocs\advance\my-ecommerce\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>