<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class AdminOrderController extends Controller
{
    public function index(){
        return view('admin.order.index',['orders' => Order::orderBy('id','desc')->get()]);
    }

    public function edit($id){
        return view('admin.order.edit',['order' => Order::find($id)]);
    }

    public function orderDetails($id){
        return view('admin.order.detail',['order' => Order::find($id)]);
    }

    public function orderInvoice($id){
        return view('admin.order.show-invoice',['orders' => Order::orderBy('id','desc')->get()]);
    }

    public function printInvoice($id){
        return view('admin.order.print-invoice',['orders' => Order::orderBy('id','desc')->get()]);
    }

    public function delete($id){
        return $id;
    }
}
