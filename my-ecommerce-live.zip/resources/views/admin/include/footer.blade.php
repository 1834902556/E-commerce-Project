<footer class="footer">
    © 2021 Design & Developed by Najmul Islam
    <a href="https://www.wrappixel.com/">WrapPixel</a>
</footer>
